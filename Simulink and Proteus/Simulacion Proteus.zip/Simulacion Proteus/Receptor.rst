                              1 ;--------------------------------------------------------
                              2 ; File Created by SDCC : FreeWare ANSI-C Compiler
                              3 ; Version 2.4.0 Thu Jan 02 18:08:24 2014
                              4 
                              5 ;--------------------------------------------------------
                              6 	.module Receptor
                              7 	.optsdcc -mmcs51 --model-small
                              8 	
                              9 ;--------------------------------------------------------
                             10 ; Public variables in this module
                             11 ;--------------------------------------------------------
                             12 	.globl _ByteOk
                             13 	.globl _ByteError
                             14 	.globl _main
                             15 	.globl _suma
                             16 	.globl _k
                             17 	.globl _i
                             18 	.globl _Recibido
                             19 	.globl _PuertoSerie
                             20 ;--------------------------------------------------------
                             21 ; special function registers
                             22 ;--------------------------------------------------------
                    0080     23 _P0	=	0x0080
                    0081     24 _SP	=	0x0081
                    0082     25 _DPL	=	0x0082
                    0083     26 _DPH	=	0x0083
                    0087     27 _PCON	=	0x0087
                    0088     28 _TCON	=	0x0088
                    0089     29 _TMOD	=	0x0089
                    008A     30 _TL0	=	0x008a
                    008B     31 _TL1	=	0x008b
                    008C     32 _TH0	=	0x008c
                    008D     33 _TH1	=	0x008d
                    0090     34 _P1	=	0x0090
                    0098     35 _SCON	=	0x0098
                    0099     36 _SBUF	=	0x0099
                    00A0     37 _P2	=	0x00a0
                    00A8     38 _IE	=	0x00a8
                    00B0     39 _P3	=	0x00b0
                    00B8     40 _IP	=	0x00b8
                    00D0     41 _PSW	=	0x00d0
                    00E0     42 _ACC	=	0x00e0
                    00F0     43 _B	=	0x00f0
                             44 ;--------------------------------------------------------
                             45 ; special function bits 
                             46 ;--------------------------------------------------------
                    0080     47 _P0_0	=	0x0080
                    0081     48 _P0_1	=	0x0081
                    0082     49 _P0_2	=	0x0082
                    0083     50 _P0_3	=	0x0083
                    0084     51 _P0_4	=	0x0084
                    0085     52 _P0_5	=	0x0085
                    0086     53 _P0_6	=	0x0086
                    0087     54 _P0_7	=	0x0087
                    0088     55 _IT0	=	0x0088
                    0089     56 _IE0	=	0x0089
                    008A     57 _IT1	=	0x008a
                    008B     58 _IE1	=	0x008b
                    008C     59 _TR0	=	0x008c
                    008D     60 _TF0	=	0x008d
                    008E     61 _TR1	=	0x008e
                    008F     62 _TF1	=	0x008f
                    0090     63 _P1_0	=	0x0090
                    0091     64 _P1_1	=	0x0091
                    0092     65 _P1_2	=	0x0092
                    0093     66 _P1_3	=	0x0093
                    0094     67 _P1_4	=	0x0094
                    0095     68 _P1_5	=	0x0095
                    0096     69 _P1_6	=	0x0096
                    0097     70 _P1_7	=	0x0097
                    0098     71 _RI	=	0x0098
                    0099     72 _TI	=	0x0099
                    009A     73 _RB8	=	0x009a
                    009B     74 _TB8	=	0x009b
                    009C     75 _REN	=	0x009c
                    009D     76 _SM2	=	0x009d
                    009E     77 _SM1	=	0x009e
                    009F     78 _SM0	=	0x009f
                    00A0     79 _P2_0	=	0x00a0
                    00A1     80 _P2_1	=	0x00a1
                    00A2     81 _P2_2	=	0x00a2
                    00A3     82 _P2_3	=	0x00a3
                    00A4     83 _P2_4	=	0x00a4
                    00A5     84 _P2_5	=	0x00a5
                    00A6     85 _P2_6	=	0x00a6
                    00A7     86 _P2_7	=	0x00a7
                    00A8     87 _EX0	=	0x00a8
                    00A9     88 _ET0	=	0x00a9
                    00AA     89 _EX1	=	0x00aa
                    00AB     90 _ET1	=	0x00ab
                    00AC     91 _ES	=	0x00ac
                    00AF     92 _EA	=	0x00af
                    00B0     93 _P3_0	=	0x00b0
                    00B1     94 _P3_1	=	0x00b1
                    00B2     95 _P3_2	=	0x00b2
                    00B3     96 _P3_3	=	0x00b3
                    00B4     97 _P3_4	=	0x00b4
                    00B5     98 _P3_5	=	0x00b5
                    00B6     99 _P3_6	=	0x00b6
                    00B7    100 _P3_7	=	0x00b7
                    00B0    101 _RXD	=	0x00b0
                    00B1    102 _TXD	=	0x00b1
                    00B2    103 _INT0	=	0x00b2
                    00B3    104 _INT1	=	0x00b3
                    00B4    105 _T0	=	0x00b4
                    00B5    106 _T1	=	0x00b5
                    00B6    107 _WR	=	0x00b6
                    00B7    108 _RD	=	0x00b7
                    00B8    109 _PX0	=	0x00b8
                    00B9    110 _PT0	=	0x00b9
                    00BA    111 _PX1	=	0x00ba
                    00BB    112 _PT1	=	0x00bb
                    00BC    113 _PS	=	0x00bc
                    00D0    114 _P	=	0x00d0
                    00D1    115 _F1	=	0x00d1
                    00D2    116 _OV	=	0x00d2
                    00D3    117 _RS0	=	0x00d3
                    00D4    118 _RS1	=	0x00d4
                    00D5    119 _F0	=	0x00d5
                    00D6    120 _AC	=	0x00d6
                    00D7    121 _CY	=	0x00d7
                            122 ;--------------------------------------------------------
                            123 ; overlayable register banks 
                            124 ;--------------------------------------------------------
                            125 	.area REG_BANK_0	(REL,OVR,DATA)
   0000                     126 	.ds 8
                            127 ;--------------------------------------------------------
                            128 ; internal ram data
                            129 ;--------------------------------------------------------
                            130 	.area DSEG    (DATA)
   0008                     131 _Recibido::
   0008                     132 	.ds 30
   0026                     133 _i::
   0026                     134 	.ds 1
   0027                     135 _k::
   0027                     136 	.ds 1
   0028                     137 _suma::
   0028                     138 	.ds 1
                            139 ;--------------------------------------------------------
                            140 ; overlayable items in internal ram 
                            141 ;--------------------------------------------------------
                            142 	.area OSEG    (OVR,DATA)
                            143 ;--------------------------------------------------------
                            144 ; Stack segment in internal ram 
                            145 ;--------------------------------------------------------
                            146 	.area	SSEG	(DATA)
   00D0                     147 __start__stack:
   00D0                     148 	.ds	1
                            149 
                            150 ;--------------------------------------------------------
                            151 ; indirectly addressable internal ram data
                            152 ;--------------------------------------------------------
                            153 	.area ISEG    (DATA)
                            154 ;--------------------------------------------------------
                            155 ; bit data
                            156 ;--------------------------------------------------------
                            157 	.area BSEG    (BIT)
                            158 ;--------------------------------------------------------
                            159 ; external ram data
                            160 ;--------------------------------------------------------
                            161 	.area XSEG    (XDATA)
                            162 ;--------------------------------------------------------
                            163 ; external initialized ram data
                            164 ;--------------------------------------------------------
                            165 	.area XISEG   (XDATA)
                            166 ;--------------------------------------------------------
                            167 ; interrupt vector 
                            168 ;--------------------------------------------------------
                            169 	.area CSEG    (CODE)
   0000                     170 __interrupt_vect:
   0000 02 00 F1            171 	ljmp	__sdcc_gsinit_startup
   0003 32                  172 	reti
   0004                     173 	.ds	7
   000B 32                  174 	reti
   000C                     175 	.ds	7
   0013 32                  176 	reti
   0014                     177 	.ds	7
   001B 32                  178 	reti
   001C                     179 	.ds	7
   0023 02 00 4C            180 	ljmp	_PuertoSerie
   0026                     181 	.ds	5
   002B 32                  182 	reti
                            183 ;--------------------------------------------------------
                            184 ; global & static initialisations
                            185 ;--------------------------------------------------------
                            186 	.area GSINIT  (CODE)
                            187 	.area GSFINAL (CODE)
                            188 	.area GSINIT  (CODE)
   00F1                     189 __sdcc_gsinit_startup:
   00F1 75 81 CF            190 	mov	sp,#__start__stack - 1
   00F4 12 00 ED            191 	lcall	__sdcc_external_startup
   00F7 E5 82               192 	mov	a,dpl
   00F9 60 03               193 	jz	__sdcc_init_data
   00FB 02 00 2C            194 	ljmp	__sdcc_program_startup
   00FE                     195 __sdcc_init_data:
                            196 ;	_mcs51_genXINIT() start
   00FE 79 00               197 	mov	r1,#l_XINIT
   0100 E9                  198 	mov	a,r1
   0101 44 00               199 	orl	a,#(l_XINIT >> 8)
   0103 60 1B               200 	jz	00003$
   0105 7A 00               201 	mov	r2,#((l_XINIT+255) >> 8)
   0107 90 01 42            202 	mov	dptr,#s_XINIT
   010A 78 00               203 	mov	r0,#s_XISEG
   010C 75 A0 00            204 	mov	p2,#(s_XISEG >> 8)
   010F E4                  205 00001$:	clr	a
   0110 93                  206 	movc	a,@a+dptr
   0111 F2                  207 	movx	@r0,a
   0112 A3                  208 	inc	dptr
   0113 08                  209 	inc	r0
   0114 B8 00 02            210 	cjne	r0,#0,00002$
   0117 05 A0               211 	inc	p2
   0119 D9 F4               212 00002$:	djnz	r1,00001$
   011B DA F2               213 	djnz	r2,00001$
   011D 75 A0 FF            214 	mov	p2,#0xFF
   0120                     215 00003$:
                            216 ;	_mcs51_genXINIT() end
                            217 ;	_mcs51_genRAMCLEAR() start
   0120 78 00               218 	mov	r0,#l_XSEG
   0122 E8                  219 	mov	a,r0
   0123 44 00               220 	orl	a,#(l_XSEG >> 8)
   0125 60 0C               221 	jz	00005$
   0127 79 00               222 	mov	r1,#((l_XSEG + 255) >> 8)
   0129 90 00 00            223 	mov	dptr,#s_XSEG
   012C E4                  224 	clr     a
   012D F0                  225 00004$:	movx	@dptr,a
   012E A3                  226 	inc	dptr
   012F D8 FC               227 	djnz	r0,00004$
   0131 D9 FA               228 	djnz	r1,00004$
   0133 F6                  229 00005$:	mov	@r0,a
   0134 D8 FD               230 	djnz	r0,00005$
                            231 ;	_mcs51_genRAMCLEAR() end
                            232 ;Receptor.c:8: char i=0;
                            233 ;     genAssign
   0136 75 26 00            234 	mov	_i,#0x00
                            235 ;Receptor.c:9: char k=0;
                            236 ;     genAssign
   0139 75 27 00            237 	mov	_k,#0x00
                            238 ;Receptor.c:10: char suma=0;
                            239 ;     genAssign
   013C 75 28 00            240 	mov	_suma,#0x00
                            241 	.area GSFINAL (CODE)
   013F 02 00 2C            242 	ljmp	__sdcc_program_startup
                            243 ;--------------------------------------------------------
                            244 ; Home
                            245 ;--------------------------------------------------------
                            246 	.area HOME    (CODE)
                            247 	.area CSEG    (CODE)
                            248 ;--------------------------------------------------------
                            249 ; code
                            250 ;--------------------------------------------------------
                            251 	.area CSEG    (CODE)
   002C                     252 __sdcc_program_startup:
   002C 12 00 31            253 	lcall	_main
                            254 ;	return from main will lock up
   002F 80 FE               255 	sjmp .
                            256 ;------------------------------------------------------------
                            257 ;Allocation info for local variables in function 'main'
                            258 ;------------------------------------------------------------
                            259 ;------------------------------------------------------------
                            260 ;Receptor.c:14: void main (void) 
                            261 ;	-----------------------------------------
                            262 ;	 function main
                            263 ;	-----------------------------------------
   0031                     264 _main:
                    0002    265 	ar2 = 0x02
                    0003    266 	ar3 = 0x03
                    0004    267 	ar4 = 0x04
                    0005    268 	ar5 = 0x05
                    0006    269 	ar6 = 0x06
                    0007    270 	ar7 = 0x07
                    0000    271 	ar0 = 0x00
                    0001    272 	ar1 = 0x01
                            273 ;Receptor.c:16: TMOD=0x20;    //modo 2 el timer 1 
                            274 ;     genAssign
   0031 75 89 20            275 	mov	_TMOD,#0x20
                            276 ;Receptor.c:17: IE=0x90;
                            277 ;     genAssign
   0034 75 A8 90            278 	mov	_IE,#0x90
                            279 ;Receptor.c:18: IP=0x10;      
                            280 ;     genAssign
   0037 75 B8 10            281 	mov	_IP,#0x10
                            282 ;Receptor.c:19: SM0=0;
                            283 ;     genAssign
   003A C2 9F               284 	clr	_SM0
                            285 ;Receptor.c:20: SM1=1;       //configurando el modo 1 del puerto serie
                            286 ;     genAssign
   003C D2 9E               287 	setb	_SM1
                            288 ;Receptor.c:22: TH1=241;     //cargando mi Vt de 2.08kbps
                            289 ;     genAssign
   003E 75 8D F1            290 	mov	_TH1,#0xF1
                            291 ;Receptor.c:24: IT0=1;
                            292 ;     genAssign
   0041 D2 88               293 	setb	_IT0
                            294 ;Receptor.c:25: IT1=1;
                            295 ;     genAssign
   0043 D2 8A               296 	setb	_IT1
                            297 ;Receptor.c:26: REN=1;
                            298 ;     genAssign
   0045 D2 9C               299 	setb	_REN
                            300 ;Receptor.c:27: TR1=1;       
                            301 ;     genAssign
   0047 D2 8E               302 	setb	_TR1
   0049                     303 00102$:
                            304 ;       Peephole 112.b  changed ljmp to sjmp
   0049 80 FE               305 	sjmp    00102$
   004B                     306 00104$:
   004B 22                  307 	ret
                            308 ;------------------------------------------------------------
                            309 ;Allocation info for local variables in function 'PuertoSerie'
                            310 ;------------------------------------------------------------
                            311 ;------------------------------------------------------------
                            312 ;Receptor.c:37: void PuertoSerie(void) interrupt 4
                            313 ;	-----------------------------------------
                            314 ;	 function PuertoSerie
                            315 ;	-----------------------------------------
   004C                     316 _PuertoSerie:
   004C C0 E0               317 	push	acc
   004E C0 F0               318 	push	b
   0050 C0 82               319 	push	dpl
   0052 C0 83               320 	push	dph
   0054 C0 02               321 	push	ar2
   0056 C0 03               322 	push	ar3
   0058 C0 04               323 	push	ar4
   005A C0 05               324 	push	ar5
   005C C0 00               325 	push	ar0
   005E C0 D0               326 	push	psw
   0060 75 D0 00            327 	mov	psw,#0x00
                            328 ;Receptor.c:78: }
                            329 ;     genIfx
                            330 ;     genIfxJump
                            331 ;       Peephole 111    removed ljmp by inverse jump logic
                            332 ;Receptor.c:41: TI=0;
                            333 ;     genAssign
                            334 ;       Peephole 250.a  using atomic test and clear
   0063 10 99 02            335 	jbc     _TI,00117$
   0066 80 03               336 	sjmp    00102$
   0068                     337 00117$:
                            338 ;Receptor.c:42: return;
                            339 ;     genRet
   0068 02 00 D6            340 	ljmp	00111$
   006B                     341 00102$:
                            342 ;Receptor.c:45: if(k!=6)
                            343 ;     genCmpEq
   006B E5 27               344 	mov	a,_k
   006D B4 06 02            345 	cjne	a,#0x06,00118$
                            346 ;       Peephole 112.b  changed ljmp to sjmp
   0070 80 1E               347 	sjmp    00109$
   0072                     348 00118$:
                            349 ;Receptor.c:48: Recibido[i]=SBUF;
                            350 ;     genPlus
   0072 E5 26               351 	mov	a,_i
   0074 24 08               352 	add	a,#_Recibido
   0076 F8                  353 	mov	r0,a
                            354 ;     genAssign
   0077 AA 99               355 	mov	r2,_SBUF
                            356 ;     genPointerSet
                            357 ;     genNearPointerSet
   0079 A6 02               358 	mov	@r0,ar2
                            359 ;Receptor.c:49: suma=suma+Recibido[i];
                            360 ;     genPlus
                            361 ;       Peephole 236.g  used r2 instead of ar2
   007B EA                  362 	mov     a,r2
   007C 25 28               363 	add	a,_suma
   007E F5 28               364 	mov	_suma,a
                            365 ;Receptor.c:50: i++;
                            366 ;     genPlus
                            367 ;     genPlusIncr
   0080 05 26               368 	inc	_i
                            369 ;Receptor.c:51: k++;
                            370 ;     genPlus
                            371 ;     genPlusIncr
   0082 05 27               372 	inc	_k
                            373 ;Receptor.c:53: if(i==30)             //esto es un buffer circular
                            374 ;     genCmpEq
   0084 E5 26               375 	mov	a,_i
                            376 ;       Peephole 112.b  changed ljmp to sjmp
                            377 ;       Peephole 199    optimized misc jump sequence
   0086 B4 1E 4B            378 	cjne    a,#0x1E,00110$
                            379 ;00119$:
                            380 ;       Peephole 200    removed redundant sjmp
   0089                     381 00120$:
                            382 ;Receptor.c:55: i=0;
                            383 ;     genAssign
   0089 75 26 00            384 	mov	_i,#0x00
                            385 ;Receptor.c:56: P1_2=!P1_2;       //indica reinicio del buffer
                            386 ;     genNot
                            387 ;       Peephole 167    removed redundant bit moves (c not set to _P1_2)
   008C B2 92               388 	cpl     _P1_2
                            389 ;       Peephole 112.b  changed ljmp to sjmp
   008E 80 44               390 	sjmp    00110$
   0090                     391 00109$:
                            392 ;Receptor.c:61: k=0;
                            393 ;     genAssign
   0090 75 27 00            394 	mov	_k,#0x00
                            395 ;Receptor.c:62: Recibido[i]=SBUF;
                            396 ;     genPlus
   0093 E5 26               397 	mov	a,_i
   0095 24 08               398 	add	a,#_Recibido
   0097 F8                  399 	mov	r0,a
                            400 ;     genAssign
   0098 AA 99               401 	mov	r2,_SBUF
                            402 ;     genPointerSet
                            403 ;     genNearPointerSet
   009A A6 02               404 	mov	@r0,ar2
                            405 ;Receptor.c:63: if((suma+Recibido[i])==0x00)
                            406 ;     genCast
   009C AB 28               407 	mov	r3,_suma
   009E E5 28               408 	mov	a,_suma
   00A0 33                  409 	rlc	a
   00A1 95 E0               410 	subb	a,acc
   00A3 FC                  411 	mov	r4,a
                            412 ;     genCast
   00A4 EA                  413 	mov	a,r2
   00A5 33                  414 	rlc	a
   00A6 95 E0               415 	subb	a,acc
   00A8 FD                  416 	mov	r5,a
                            417 ;     genPlus
                            418 ;       Peephole 236.g  used r2 instead of ar2
   00A9 EA                  419 	mov     a,r2
                            420 ;       Peephole 236.a  used r3 instead of ar3
   00AA 2B                  421 	add     a,r3
   00AB FB                  422 	mov	r3,a
                            423 ;       Peephole 236.g  used r5 instead of ar5
   00AC ED                  424 	mov     a,r5
                            425 ;       Peephole 236.b  used r4 instead of ar4
   00AD 3C                  426 	addc    a,r4
   00AE FC                  427 	mov	r4,a
                            428 ;     genCmpEq
                            429 ;       Peephole 112.b  changed ljmp to sjmp
                            430 ;       Peephole 198    optimized misc jump sequence
   00AF BB 00 10            431 	cjne    r3,#0x00,00106$
   00B2 BC 00 0D            432 	cjne    r4,#0x00,00106$
                            433 ;00121$:
                            434 ;       Peephole 200    removed redundant sjmp
   00B5                     435 00122$:
                            436 ;Receptor.c:65: P1_0=!P1_0;       //indica que la transmisi�n de la trama fue un �xito
                            437 ;     genNot
                            438 ;       Peephole 167    removed redundant bit moves (c not set to _P1_0)
   00B5 B2 90               439 	cpl     _P1_0
                            440 ;Receptor.c:66: P1_1=1;           //indica que si hubo un error fue corregido
                            441 ;     genAssign
   00B7 D2 91               442 	setb	_P1_1
                            443 ;Receptor.c:67: SBUF=ByteOk;     //env�a byte de confirmaci�n
                            444 ;     genAssign
   00B9 90 00 EC            445 	mov	dptr,#_ByteOk
   00BC E4                  446 	clr	a
   00BD 93                  447 	movc	a,@a+dptr
   00BE F5 99               448 	mov	_SBUF,a
                            449 ;       Peephole 112.b  changed ljmp to sjmp
   00C0 80 0F               450 	sjmp    00107$
   00C2                     451 00106$:
                            452 ;Receptor.c:72: P1_1=0;           //indica que hubo un error
                            453 ;     genAssign
   00C2 C2 91               454 	clr	_P1_1
                            455 ;Receptor.c:73: SBUF=ByteError;  //env�a byte de error
                            456 ;     genAssign
   00C4 90 00 EB            457 	mov	dptr,#_ByteError
   00C7 E4                  458 	clr	a
   00C8 93                  459 	movc	a,@a+dptr
   00C9 F5 99               460 	mov	_SBUF,a
                            461 ;Receptor.c:74: i=i-6;            //sobreescribo en el error
                            462 ;     genMinus
   00CB E5 26               463 	mov	a,_i
   00CD 24 FA               464 	add	a,#0xfa
   00CF F5 26               465 	mov	_i,a
   00D1                     466 00107$:
                            467 ;Receptor.c:76: suma=0;
                            468 ;     genAssign
   00D1 75 28 00            469 	mov	_suma,#0x00
   00D4                     470 00110$:
                            471 ;Receptor.c:80: RI=0; 
                            472 ;     genAssign
   00D4 C2 98               473 	clr	_RI
   00D6                     474 00111$:
   00D6 D0 D0               475 	pop	psw
   00D8 D0 00               476 	pop	ar0
   00DA D0 05               477 	pop	ar5
   00DC D0 04               478 	pop	ar4
   00DE D0 03               479 	pop	ar3
   00E0 D0 02               480 	pop	ar2
   00E2 D0 83               481 	pop	dph
   00E4 D0 82               482 	pop	dpl
   00E6 D0 F0               483 	pop	b
   00E8 D0 E0               484 	pop	acc
   00EA 32                  485 	reti
                            486 	.area CSEG    (CODE)
   00EB                     487 _ByteError:
   00EB FE                  488 	.db #0xFE
   00EC                     489 _ByteOk:
   00EC 01                  490 	.db #0x01
                            491 	.area XINIT   (CODE)
