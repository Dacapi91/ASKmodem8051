                              1 ;--------------------------------------------------------
                              2 ; File Created by SDCC : FreeWare ANSI-C Compiler
                              3 ; Version 2.4.0 Thu Jan 02 12:59:41 2014
                              4 
                              5 ;--------------------------------------------------------
                              6 	.module sine
                              7 	.optsdcc -mmcs51 --model-small
                              8 	
                              9 ;--------------------------------------------------------
                             10 ; Public variables in this module
                             11 ;--------------------------------------------------------
                             12 	.globl _Caracteres
                             13 	.globl _tabla
                             14 	.globl _SimError
                             15 	.globl _main
                             16 	.globl _indicador
                             17 	.globl _e
                             18 	.globl _c
                             19 	.globl _comprobacion
                             20 	.globl _error
                             21 	.globl _k
                             22 	.globl _j
                             23 	.globl _i
                             24 	.globl _Ts
                             25 	.globl _Cero
                             26 	.globl _Uno
                             27 	.globl _PuertoSerie
                             28 	.globl _Transmitir
                             29 	.globl _SimularError
                             30 ;--------------------------------------------------------
                             31 ; special function registers
                             32 ;--------------------------------------------------------
                    0080     33 _P0	=	0x0080
                    0081     34 _SP	=	0x0081
                    0082     35 _DPL	=	0x0082
                    0083     36 _DPH	=	0x0083
                    0087     37 _PCON	=	0x0087
                    0088     38 _TCON	=	0x0088
                    0089     39 _TMOD	=	0x0089
                    008A     40 _TL0	=	0x008a
                    008B     41 _TL1	=	0x008b
                    008C     42 _TH0	=	0x008c
                    008D     43 _TH1	=	0x008d
                    0090     44 _P1	=	0x0090
                    0098     45 _SCON	=	0x0098
                    0099     46 _SBUF	=	0x0099
                    00A0     47 _P2	=	0x00a0
                    00A8     48 _IE	=	0x00a8
                    00B0     49 _P3	=	0x00b0
                    00B8     50 _IP	=	0x00b8
                    00D0     51 _PSW	=	0x00d0
                    00E0     52 _ACC	=	0x00e0
                    00F0     53 _B	=	0x00f0
                             54 ;--------------------------------------------------------
                             55 ; special function bits 
                             56 ;--------------------------------------------------------
                    0080     57 _P0_0	=	0x0080
                    0081     58 _P0_1	=	0x0081
                    0082     59 _P0_2	=	0x0082
                    0083     60 _P0_3	=	0x0083
                    0084     61 _P0_4	=	0x0084
                    0085     62 _P0_5	=	0x0085
                    0086     63 _P0_6	=	0x0086
                    0087     64 _P0_7	=	0x0087
                    0088     65 _IT0	=	0x0088
                    0089     66 _IE0	=	0x0089
                    008A     67 _IT1	=	0x008a
                    008B     68 _IE1	=	0x008b
                    008C     69 _TR0	=	0x008c
                    008D     70 _TF0	=	0x008d
                    008E     71 _TR1	=	0x008e
                    008F     72 _TF1	=	0x008f
                    0090     73 _P1_0	=	0x0090
                    0091     74 _P1_1	=	0x0091
                    0092     75 _P1_2	=	0x0092
                    0093     76 _P1_3	=	0x0093
                    0094     77 _P1_4	=	0x0094
                    0095     78 _P1_5	=	0x0095
                    0096     79 _P1_6	=	0x0096
                    0097     80 _P1_7	=	0x0097
                    0098     81 _RI	=	0x0098
                    0099     82 _TI	=	0x0099
                    009A     83 _RB8	=	0x009a
                    009B     84 _TB8	=	0x009b
                    009C     85 _REN	=	0x009c
                    009D     86 _SM2	=	0x009d
                    009E     87 _SM1	=	0x009e
                    009F     88 _SM0	=	0x009f
                    00A0     89 _P2_0	=	0x00a0
                    00A1     90 _P2_1	=	0x00a1
                    00A2     91 _P2_2	=	0x00a2
                    00A3     92 _P2_3	=	0x00a3
                    00A4     93 _P2_4	=	0x00a4
                    00A5     94 _P2_5	=	0x00a5
                    00A6     95 _P2_6	=	0x00a6
                    00A7     96 _P2_7	=	0x00a7
                    00A8     97 _EX0	=	0x00a8
                    00A9     98 _ET0	=	0x00a9
                    00AA     99 _EX1	=	0x00aa
                    00AB    100 _ET1	=	0x00ab
                    00AC    101 _ES	=	0x00ac
                    00AF    102 _EA	=	0x00af
                    00B0    103 _P3_0	=	0x00b0
                    00B1    104 _P3_1	=	0x00b1
                    00B2    105 _P3_2	=	0x00b2
                    00B3    106 _P3_3	=	0x00b3
                    00B4    107 _P3_4	=	0x00b4
                    00B5    108 _P3_5	=	0x00b5
                    00B6    109 _P3_6	=	0x00b6
                    00B7    110 _P3_7	=	0x00b7
                    00B0    111 _RXD	=	0x00b0
                    00B1    112 _TXD	=	0x00b1
                    00B2    113 _INT0	=	0x00b2
                    00B3    114 _INT1	=	0x00b3
                    00B4    115 _T0	=	0x00b4
                    00B5    116 _T1	=	0x00b5
                    00B6    117 _WR	=	0x00b6
                    00B7    118 _RD	=	0x00b7
                    00B8    119 _PX0	=	0x00b8
                    00B9    120 _PT0	=	0x00b9
                    00BA    121 _PX1	=	0x00ba
                    00BB    122 _PT1	=	0x00bb
                    00BC    123 _PS	=	0x00bc
                    00D0    124 _P	=	0x00d0
                    00D1    125 _F1	=	0x00d1
                    00D2    126 _OV	=	0x00d2
                    00D3    127 _RS0	=	0x00d3
                    00D4    128 _RS1	=	0x00d4
                    00D5    129 _F0	=	0x00d5
                    00D6    130 _AC	=	0x00d6
                    00D7    131 _CY	=	0x00d7
                            132 ;--------------------------------------------------------
                            133 ; overlayable register banks 
                            134 ;--------------------------------------------------------
                            135 	.area REG_BANK_0	(REL,OVR,DATA)
   0000                     136 	.ds 8
                            137 ;--------------------------------------------------------
                            138 ; internal ram data
                            139 ;--------------------------------------------------------
                            140 	.area DSEG    (DATA)
   0021                     141 _i::
   0021                     142 	.ds 1
   0022                     143 _j::
   0022                     144 	.ds 1
   0023                     145 _k::
   0023                     146 	.ds 1
   0024                     147 _error::
   0024                     148 	.ds 1
   0025                     149 _comprobacion::
   0025                     150 	.ds 1
                            151 ;--------------------------------------------------------
                            152 ; overlayable items in internal ram 
                            153 ;--------------------------------------------------------
                            154 	.area OSEG    (OVR,DATA)
                            155 ;--------------------------------------------------------
                            156 ; Stack segment in internal ram 
                            157 ;--------------------------------------------------------
                            158 	.area	SSEG	(DATA)
   00D0                     159 __start__stack:
   00D0                     160 	.ds	1
                            161 
                            162 ;--------------------------------------------------------
                            163 ; indirectly addressable internal ram data
                            164 ;--------------------------------------------------------
                            165 	.area ISEG    (DATA)
                            166 ;--------------------------------------------------------
                            167 ; bit data
                            168 ;--------------------------------------------------------
                            169 	.area BSEG    (BIT)
   0000                     170 _c::
   0000                     171 	.ds 1
   0001                     172 _e::
   0001                     173 	.ds 1
   0002                     174 _indicador::
   0002                     175 	.ds 1
                            176 ;--------------------------------------------------------
                            177 ; external ram data
                            178 ;--------------------------------------------------------
                            179 	.area XSEG    (XDATA)
                            180 ;--------------------------------------------------------
                            181 ; external initialized ram data
                            182 ;--------------------------------------------------------
                            183 	.area XISEG   (XDATA)
                            184 ;--------------------------------------------------------
                            185 ; interrupt vector 
                            186 ;--------------------------------------------------------
                            187 	.area CSEG    (CODE)
   0000                     188 __interrupt_vect:
   0000 02 01 88            189 	ljmp	__sdcc_gsinit_startup
   0003 02 00 8A            190 	ljmp	_Cero
   0006                     191 	.ds	5
   000B 02 00 58            192 	ljmp	_Ts
   000E                     193 	.ds	5
   0013 02 00 A4            194 	ljmp	_Uno
   0016                     195 	.ds	5
   001B 32                  196 	reti
   001C                     197 	.ds	7
   0023 02 00 BE            198 	ljmp	_PuertoSerie
   0026                     199 	.ds	5
   002B 32                  200 	reti
                            201 ;--------------------------------------------------------
                            202 ; global & static initialisations
                            203 ;--------------------------------------------------------
                            204 	.area GSINIT  (CODE)
                            205 	.area GSFINAL (CODE)
                            206 	.area GSINIT  (CODE)
   0188                     207 __sdcc_gsinit_startup:
   0188 75 81 CF            208 	mov	sp,#__start__stack - 1
   018B 12 01 84            209 	lcall	__sdcc_external_startup
   018E E5 82               210 	mov	a,dpl
   0190 60 03               211 	jz	__sdcc_init_data
   0192 02 00 2C            212 	ljmp	__sdcc_program_startup
   0195                     213 __sdcc_init_data:
                            214 ;	_mcs51_genXINIT() start
   0195 79 00               215 	mov	r1,#l_XINIT
   0197 E9                  216 	mov	a,r1
   0198 44 00               217 	orl	a,#(l_XINIT >> 8)
   019A 60 1B               218 	jz	00003$
   019C 7A 00               219 	mov	r2,#((l_XINIT+255) >> 8)
   019E 90 01 E5            220 	mov	dptr,#s_XINIT
   01A1 78 00               221 	mov	r0,#s_XISEG
   01A3 75 A0 00            222 	mov	p2,#(s_XISEG >> 8)
   01A6 E4                  223 00001$:	clr	a
   01A7 93                  224 	movc	a,@a+dptr
   01A8 F2                  225 	movx	@r0,a
   01A9 A3                  226 	inc	dptr
   01AA 08                  227 	inc	r0
   01AB B8 00 02            228 	cjne	r0,#0,00002$
   01AE 05 A0               229 	inc	p2
   01B0 D9 F4               230 00002$:	djnz	r1,00001$
   01B2 DA F2               231 	djnz	r2,00001$
   01B4 75 A0 FF            232 	mov	p2,#0xFF
   01B7                     233 00003$:
                            234 ;	_mcs51_genXINIT() end
                            235 ;	_mcs51_genRAMCLEAR() start
   01B7 78 00               236 	mov	r0,#l_XSEG
   01B9 E8                  237 	mov	a,r0
   01BA 44 00               238 	orl	a,#(l_XSEG >> 8)
   01BC 60 0C               239 	jz	00005$
   01BE 79 00               240 	mov	r1,#((l_XSEG + 255) >> 8)
   01C0 90 00 00            241 	mov	dptr,#s_XSEG
   01C3 E4                  242 	clr     a
   01C4 F0                  243 00004$:	movx	@dptr,a
   01C5 A3                  244 	inc	dptr
   01C6 D8 FC               245 	djnz	r0,00004$
   01C8 D9 FA               246 	djnz	r1,00004$
   01CA F6                  247 00005$:	mov	@r0,a
   01CB D8 FD               248 	djnz	r0,00005$
                            249 ;	_mcs51_genRAMCLEAR() end
                            250 ;sine.c:13: char i=0;
                            251 ;     genAssign
   01CD 75 21 00            252 	mov	_i,#0x00
                            253 ;sine.c:14: char j=0;
                            254 ;     genAssign
   01D0 75 22 00            255 	mov	_j,#0x00
                            256 ;sine.c:15: char k=0;
                            257 ;     genAssign
   01D3 75 23 00            258 	mov	_k,#0x00
                            259 ;sine.c:17: char error=0;
                            260 ;     genAssign
   01D6 75 24 00            261 	mov	_error,#0x00
                            262 ;sine.c:19: char comprobacion=0;
                            263 ;     genAssign
   01D9 75 25 00            264 	mov	_comprobacion,#0x00
                            265 ;sine.c:20: bit c=0;
                            266 ;     genAssign
   01DC C2 00               267 	clr	_c
                            268 ;sine.c:21: bit e=0;
                            269 ;     genAssign
   01DE C2 01               270 	clr	_e
                            271 ;sine.c:22: bit indicador=0;
                            272 ;     genAssign
   01E0 C2 02               273 	clr	_indicador
                            274 	.area GSFINAL (CODE)
   01E2 02 00 2C            275 	ljmp	__sdcc_program_startup
                            276 ;--------------------------------------------------------
                            277 ; Home
                            278 ;--------------------------------------------------------
                            279 	.area HOME    (CODE)
                            280 	.area CSEG    (CODE)
                            281 ;--------------------------------------------------------
                            282 ; code
                            283 ;--------------------------------------------------------
                            284 	.area CSEG    (CODE)
   002C                     285 __sdcc_program_startup:
   002C 12 00 31            286 	lcall	_main
                            287 ;	return from main will lock up
   002F 80 FE               288 	sjmp .
                            289 ;------------------------------------------------------------
                            290 ;Allocation info for local variables in function 'main'
                            291 ;------------------------------------------------------------
                            292 ;------------------------------------------------------------
                            293 ;sine.c:27: void main (void) 
                            294 ;	-----------------------------------------
                            295 ;	 function main
                            296 ;	-----------------------------------------
   0031                     297 _main:
                    0002    298 	ar2 = 0x02
                    0003    299 	ar3 = 0x03
                    0004    300 	ar4 = 0x04
                    0005    301 	ar5 = 0x05
                    0006    302 	ar6 = 0x06
                    0007    303 	ar7 = 0x07
                    0000    304 	ar0 = 0x00
                    0001    305 	ar1 = 0x01
                            306 ;sine.c:29: TMOD=0x22;  //modo 2 el timer 0 y el timer 1
                            307 ;     genAssign
   0031 75 89 22            308 	mov	_TMOD,#0x22
                            309 ;sine.c:30: IE=0x97;
                            310 ;     genAssign
   0034 75 A8 97            311 	mov	_IE,#0x97
                            312 ;sine.c:31: IP=0x15;   
                            313 ;     genAssign
   0037 75 B8 15            314 	mov	_IP,#0x15
                            315 ;sine.c:32: SM0=0;
                            316 ;     genAssign
   003A C2 9F               317 	clr	_SM0
                            318 ;sine.c:33: SM1=1;      //configurando el modo 1 del puerto serie
                            319 ;     genAssign
   003C D2 9E               320 	setb	_SM1
                            321 ;sine.c:34: REN=1;      //habilito recepci�n para poder recibir trama de confirmaci�n
                            322 ;     genAssign
   003E D2 9C               323 	setb	_REN
                            324 ;sine.c:36: TH1=241;    //cargando mi Vt de 2.08kbps
                            325 ;     genAssign
   0040 75 8D F1            326 	mov	_TH1,#0xF1
                            327 ;sine.c:38: IT0=1;      //interrucpciones externas activadas por flanco de ca�da
                            328 ;     genAssign
   0043 D2 88               329 	setb	_IT0
                            330 ;sine.c:39: IT1=1;
                            331 ;     genAssign
   0045 D2 8A               332 	setb	_IT1
                            333 ;sine.c:40: TH0=-42;    //42us de Ts 
                            334 ;     genAssign
   0047 75 8C D6            335 	mov	_TH0,#0xD6
                            336 ;sine.c:41: TL0=-42;
                            337 ;     genAssign
   004A 75 8A D6            338 	mov	_TL0,#0xD6
                            339 ;sine.c:43: TR0=1;      //comienzo Ts
                            340 ;     genAssign
   004D D2 8C               341 	setb	_TR0
                            342 ;sine.c:44: TR1=1;       
                            343 ;     genAssign
   004F D2 8E               344 	setb	_TR1
                            345 ;sine.c:45: TI=1;       //entra en la interrpuci�n del puerto serie para comenzar a transmitir 
                            346 ;     genAssign
   0051 D2 99               347 	setb	_TI
   0053                     348 00102$:
                            349 ;     genDummyRead
   0053 A2 80               350 	mov	c,_P0_0
                            351 ;       Peephole 112.b  changed ljmp to sjmp
   0055 80 FC               352 	sjmp    00102$
   0057                     353 00104$:
   0057 22                  354 	ret
                            355 ;------------------------------------------------------------
                            356 ;Allocation info for local variables in function 'Ts'
                            357 ;------------------------------------------------------------
                            358 ;------------------------------------------------------------
                            359 ;sine.c:60: void Ts (void) interrupt 1   
                            360 ;	-----------------------------------------
                            361 ;	 function Ts
                            362 ;	-----------------------------------------
   0058                     363 _Ts:
   0058 C0 E0               364 	push	acc
   005A C0 F0               365 	push	b
   005C C0 82               366 	push	dpl
   005E C0 83               367 	push	dph
   0060 C0 D0               368 	push	psw
   0062 75 D0 00            369 	mov	psw,#0x00
                            370 ;sine.c:71: i++;
                            371 ;     genIfx
                            372 ;     genIfxJump
                            373 ;       Peephole 111    removed ljmp by inverse jump logic
   0065 30 00 0A            374 	jnb     _c,00102$
   0068                     375 00110$:
                            376 ;sine.c:64: P2=tabla[i];   
                            377 ;     genPlus
   0068 E5 21               378 	mov	a,_i
                            379 ;       Peephole 181    changed mov to clr
                            380 ;     genPointerGet
                            381 ;     genCodePointerGet
                            382 ;       Peephole 181    changed mov to clr
                            383 ;       Peephole 186.d  optimized movc sequence
   006A 90 01 6B            384 	mov     dptr,#_tabla
   006D 93                  385 	movc    a,@a+dptr
   006E F5 A0               386 	mov	_P2,a
                            387 ;       Peephole 112.b  changed ljmp to sjmp
   0070 80 03               388 	sjmp    00103$
   0072                     389 00102$:
                            390 ;sine.c:68: P2=128;  
                            391 ;     genAssign
   0072 75 A0 80            392 	mov	_P2,#0x80
   0075                     393 00103$:
                            394 ;sine.c:71: i++;
                            395 ;     genPlus
                            396 ;     genPlusIncr
   0075 05 21               397 	inc	_i
                            398 ;sine.c:72: if(i==12) 
                            399 ;     genCmpEq
   0077 E5 21               400 	mov	a,_i
                            401 ;       Peephole 112.b  changed ljmp to sjmp
                            402 ;       Peephole 199    optimized misc jump sequence
   0079 B4 0C 03            403 	cjne    a,#0x0C,00106$
                            404 ;00111$:
                            405 ;       Peephole 200    removed redundant sjmp
   007C                     406 00112$:
                            407 ;sine.c:73: {i=0;}
                            408 ;     genAssign
   007C 75 21 00            409 	mov	_i,#0x00
   007F                     410 00106$:
   007F D0 D0               411 	pop	psw
   0081 D0 83               412 	pop	dph
   0083 D0 82               413 	pop	dpl
   0085 D0 F0               414 	pop	b
   0087 D0 E0               415 	pop	acc
   0089 32                  416 	reti
                            417 ;------------------------------------------------------------
                            418 ;Allocation info for local variables in function 'Cero'
                            419 ;------------------------------------------------------------
                            420 ;------------------------------------------------------------
                            421 ;sine.c:77: void Cero(void) interrupt 0 //flanco de bajada
                            422 ;	-----------------------------------------
                            423 ;	 function Cero
                            424 ;	-----------------------------------------
   008A                     425 _Cero:
   008A C0 E0               426 	push	acc
   008C C0 F0               427 	push	b
   008E C0 82               428 	push	dpl
   0090 C0 83               429 	push	dph
   0092 C0 D0               430 	push	psw
   0094 75 D0 00            431 	mov	psw,#0x00
                            432 ;sine.c:79: c=0;
                            433 ;     genAssign
   0097 C2 00               434 	clr	_c
   0099                     435 00101$:
   0099 D0 D0               436 	pop	psw
   009B D0 83               437 	pop	dph
   009D D0 82               438 	pop	dpl
   009F D0 F0               439 	pop	b
   00A1 D0 E0               440 	pop	acc
   00A3 32                  441 	reti
                            442 ;------------------------------------------------------------
                            443 ;Allocation info for local variables in function 'Uno'
                            444 ;------------------------------------------------------------
                            445 ;------------------------------------------------------------
                            446 ;sine.c:83: void Uno(void) interrupt 2  //flanco de subida
                            447 ;	-----------------------------------------
                            448 ;	 function Uno
                            449 ;	-----------------------------------------
   00A4                     450 _Uno:
   00A4 C0 E0               451 	push	acc
   00A6 C0 F0               452 	push	b
   00A8 C0 82               453 	push	dpl
   00AA C0 83               454 	push	dph
   00AC C0 D0               455 	push	psw
   00AE 75 D0 00            456 	mov	psw,#0x00
                            457 ;sine.c:85: c=1;
                            458 ;     genAssign
   00B1 D2 00               459 	setb	_c
   00B3                     460 00101$:
   00B3 D0 D0               461 	pop	psw
   00B5 D0 83               462 	pop	dph
   00B7 D0 82               463 	pop	dpl
   00B9 D0 F0               464 	pop	b
   00BB D0 E0               465 	pop	acc
   00BD 32                  466 	reti
                            467 ;------------------------------------------------------------
                            468 ;Allocation info for local variables in function 'PuertoSerie'
                            469 ;------------------------------------------------------------
                            470 ;------------------------------------------------------------
                            471 ;sine.c:89: void PuertoSerie(void) interrupt 4
                            472 ;	-----------------------------------------
                            473 ;	 function PuertoSerie
                            474 ;	-----------------------------------------
   00BE                     475 _PuertoSerie:
   00BE C0 E0               476 	push	acc
   00C0 C0 F0               477 	push	b
   00C2 C0 82               478 	push	dpl
   00C4 C0 83               479 	push	dph
   00C6 C0 02               480 	push	(0+2)
   00C8 C0 03               481 	push	(0+3)
   00CA C0 04               482 	push	(0+4)
   00CC C0 05               483 	push	(0+5)
   00CE C0 06               484 	push	(0+6)
   00D0 C0 07               485 	push	(0+7)
   00D2 C0 00               486 	push	(0+0)
   00D4 C0 01               487 	push	(0+1)
   00D6 C0 D0               488 	push	psw
   00D8 75 D0 00            489 	mov	psw,#0x00
                            490 ;sine.c:125: }
                            491 ;     genIfx
                            492 ;     genIfxJump
                            493 ;       Peephole 111    removed ljmp by inverse jump logic
   00DB 30 99 0E            494 	jnb     _TI,00105$
   00DE                     495 00117$:
                            496 ;sine.c:104: TI=0;  
                            497 ;     genIfx
                            498 ;     genIfxJump
                            499 ;       Peephole 111    removed ljmp by inverse jump logic
                            500 ;sine.c:97: indicador=0;
                            501 ;     genAssign
                            502 ;       Peephole 250.a  using atomic test and clear
   00DE 10 02 02            503 	jbc     _indicador,00118$
   00E1 80 02               504 	sjmp    00102$
   00E3                     505 00118$:
                            506 ;       Peephole 112.b  changed ljmp to sjmp
   00E3 80 03               507 	sjmp    00103$
   00E5                     508 00102$:
                            509 ;sine.c:102: Transmitir();
                            510 ;     genCall
   00E5 12 01 25            511 	lcall	_Transmitir
   00E8                     512 00103$:
                            513 ;sine.c:104: TI=0;  
                            514 ;     genAssign
   00E8 C2 99               515 	clr	_TI
                            516 ;sine.c:105: return;
                            517 ;     genRet
                            518 ;       Peephole 112.b  changed ljmp to sjmp
   00EA 80 1E               519 	sjmp    00111$
   00EC                     520 00105$:
                            521 ;     genIfx
                            522 ;     genIfxJump
                            523 ;       Peephole 111    removed ljmp by inverse jump logic
   00EC 30 98 1B            524 	jnb     _RI,00111$
   00EF                     525 00119$:
                            526 ;sine.c:111: error=SBUF;
                            527 ;     genAssign
   00EF 85 99 24            528 	mov	_error,_SBUF
                            529 ;sine.c:112: if(error==0x01)
                            530 ;     genCmpEq
   00F2 E5 24               531 	mov	a,_error
                            532 ;       Peephole 112.b  changed ljmp to sjmp
                            533 ;       Peephole 199    optimized misc jump sequence
   00F4 B4 01 05            534 	cjne    a,#0x01,00107$
                            535 ;00120$:
                            536 ;       Peephole 200    removed redundant sjmp
   00F7                     537 00121$:
                            538 ;sine.c:114: Transmitir();   //comienza a transmitir la pr�xima trama
                            539 ;     genCall
   00F7 12 01 25            540 	lcall	_Transmitir
                            541 ;       Peephole 112.b  changed ljmp to sjmp
   00FA 80 0C               542 	sjmp    00108$
   00FC                     543 00107$:
                            544 ;sine.c:118: j=j-6;          //se desplaza la longitud de la trama para poder retransmitir
                            545 ;     genMinus
   00FC E5 22               546 	mov	a,_j
   00FE 24 FA               547 	add	a,#0xfa
   0100 F5 22               548 	mov	_j,a
                            549 ;sine.c:119: error=0; 
                            550 ;     genAssign
   0102 75 24 00            551 	mov	_error,#0x00
                            552 ;sine.c:120: Transmitir();   //retrasmite la trama
                            553 ;     genCall
   0105 12 01 25            554 	lcall	_Transmitir
   0108                     555 00108$:
                            556 ;sine.c:123: RI=0;       
                            557 ;     genAssign
   0108 C2 98               558 	clr	_RI
   010A                     559 00111$:
   010A D0 D0               560 	pop	psw
   010C D0 01               561 	pop	(0+1)
   010E D0 00               562 	pop	(0+0)
   0110 D0 07               563 	pop	(0+7)
   0112 D0 06               564 	pop	(0+6)
   0114 D0 05               565 	pop	(0+5)
   0116 D0 04               566 	pop	(0+4)
   0118 D0 03               567 	pop	(0+3)
   011A D0 02               568 	pop	(0+2)
   011C D0 83               569 	pop	dph
   011E D0 82               570 	pop	dpl
   0120 D0 F0               571 	pop	b
   0122 D0 E0               572 	pop	acc
   0124 32                  573 	reti
                            574 ;------------------------------------------------------------
                            575 ;Allocation info for local variables in function 'Transmitir'
                            576 ;------------------------------------------------------------
                            577 ;------------------------------------------------------------
                            578 ;sine.c:128: void Transmitir(void)
                            579 ;	-----------------------------------------
                            580 ;	 function Transmitir
                            581 ;	-----------------------------------------
   0125                     582 _Transmitir:
                            583 ;sine.c:130: if(k!=6)
                            584 ;     genCmpEq
   0125 E5 23               585 	mov	a,_k
   0127 B4 06 02            586 	cjne	a,#0x06,00110$
                            587 ;       Peephole 112.b  changed ljmp to sjmp
   012A 80 1F               588 	sjmp    00104$
   012C                     589 00110$:
                            590 ;sine.c:132: comprobacion=comprobacion-Caracteres[j];
                            591 ;     genPlus
   012C E5 22               592 	mov	a,_j
                            593 ;       Peephole 181    changed mov to clr
                            594 ;     genPointerGet
                            595 ;     genCodePointerGet
                            596 ;       Peephole 181    changed mov to clr
                            597 ;       Peephole 186.d  optimized movc sequence
   012E 90 01 77            598 	mov     dptr,#_Caracteres
   0131 93                  599 	movc    a,@a+dptr
   0132 FA                  600 	mov	r2,a
                            601 ;     genMinus
   0133 E5 25               602 	mov	a,_comprobacion
   0135 C3                  603 	clr	c
                            604 ;       Peephole 236.l  used r2 instead of ar2
   0136 9A                  605 	subb    a,r2
   0137 F5 25               606 	mov	_comprobacion,a
                            607 ;sine.c:133: SBUF=Caracteres[j];
                            608 ;     genAssign
   0139 8A 99               609 	mov	_SBUF,r2
                            610 ;sine.c:134: j++;
                            611 ;     genPlus
                            612 ;     genPlusIncr
   013B 05 22               613 	inc	_j
                            614 ;sine.c:135: k++;
                            615 ;     genPlus
                            616 ;     genPlusIncr
   013D 05 23               617 	inc	_k
                            618 ;sine.c:136: if(j==13)
                            619 ;     genCmpEq
   013F E5 22               620 	mov	a,_j
                            621 ;       Peephole 112.b  changed ljmp to sjmp
                            622 ;       Peephole 199    optimized misc jump sequence
   0141 B4 0D 14            623 	cjne    a,#0x0D,00106$
                            624 ;00111$:
                            625 ;       Peephole 200    removed redundant sjmp
   0144                     626 00112$:
                            627 ;sine.c:138: j=0;
                            628 ;     genAssign
   0144 75 22 00            629 	mov	_j,#0x00
                            630 ;sine.c:139: P1_7=!P1_7;
                            631 ;     genNot
                            632 ;       Peephole 167    removed redundant bit moves (c not set to _P1_7)
   0147 B2 97               633 	cpl     _P1_7
                            634 ;       Peephole 112.b  changed ljmp to sjmp
   0149 80 0D               635 	sjmp    00106$
   014B                     636 00104$:
                            637 ;sine.c:145: k=0;
                            638 ;     genAssign
   014B 75 23 00            639 	mov	_k,#0x00
                            640 ;sine.c:146: SBUF=comprobacion;
                            641 ;     genAssign
   014E 85 25 99            642 	mov	_SBUF,_comprobacion
                            643 ;sine.c:148: indicador=1;        //Se para la transmisi�n hasta que entre el byte de confirmaci�n
                            644 ;     genAssign
   0151 D2 02               645 	setb	_indicador
                            646 ;sine.c:149: comprobacion=0;
                            647 ;     genAssign
   0153 75 25 00            648 	mov	_comprobacion,#0x00
                            649 ;sine.c:150: P1_6=!P1_6;
                            650 ;     genNot
                            651 ;       Peephole 167    removed redundant bit moves (c not set to _P1_6)
   0156 B2 96               652 	cpl     _P1_6
   0158                     653 00106$:
   0158 22                  654 	ret
                            655 ;------------------------------------------------------------
                            656 ;Allocation info for local variables in function 'SimularError'
                            657 ;------------------------------------------------------------
                            658 ;------------------------------------------------------------
                            659 ;sine.c:155: void SimularError(void)
                            660 ;	-----------------------------------------
                            661 ;	 function SimularError
                            662 ;	-----------------------------------------
   0159                     663 _SimularError:
                            664 ;     genIfx
                            665 ;     genIfxJump
                            666 ;       Peephole 112.a  removed ljmp by inverse jump logic
   0159 20 01 0A            667 	jb      _e,00102$
   015C                     668 00107$:
                            669 ;sine.c:159: SBUF=SimError;    //simulaci�n de un error
                            670 ;     genAssign
   015C 90 01 6A            671 	mov	dptr,#_SimError
   015F E4                  672 	clr	a
   0160 93                  673 	movc	a,@a+dptr
   0161 F5 99               674 	mov	_SBUF,a
                            675 ;sine.c:160: e=1;
                            676 ;     genAssign
   0163 D2 01               677 	setb	_e
                            678 ;       Peephole 112.b  changed ljmp to sjmp
                            679 ;sine.c:164: SBUF=comprobacion;
                            680 ;     genAssign
                            681 ;       Peephole 237.a  removed sjmp to ret
   0165 22                  682 	ret
   0166                     683 00102$:
   0166 85 25 99            684 	mov     _SBUF,_comprobacion
   0169                     685 00104$:
   0169 22                  686 	ret
                            687 	.area CSEG    (CODE)
   016A                     688 _SimError:
   016A 2D                  689 	.db #0x2D
   016B                     690 _tabla:
   016B C0                  691 	.db #0xC0
   016C EF                  692 	.db #0xEF
   016D FF                  693 	.db #0xFF
   016E EF                  694 	.db #0xEF
   016F C0                  695 	.db #0xC0
   0170 80                  696 	.db #0x80
   0171 40                  697 	.db #0x40
   0172 11                  698 	.db #0x11
   0173 00                  699 	.db #0x00
   0174 11                  700 	.db #0x11
   0175 40                  701 	.db #0x40
   0176 80                  702 	.db #0x80
   0177                     703 _Caracteres:
   0177 48 6F 6C 61 4D 6F   704 	.ascii "HolaModemLoco"
        64 65 6D 4C 6F 63
        6F
                            705 	.area XINIT   (CODE)
